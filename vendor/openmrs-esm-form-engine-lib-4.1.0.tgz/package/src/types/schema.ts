import { type OpenmrsResource } from '@openmrs/esm-framework';
import { type OpenmrsEncounter } from './domain';

export interface FormSchema {
  name: string;
  pages: Array<FormPage>;
  processor: string;
  uuid: string;
  referencedForms: Array<ReferencedForm>;
  encounterType: string;
  encounter?: string | OpenmrsEncounter;
  allowUnspecifiedAll?: boolean;
  defaultPage?: string;
  readonly?: string | boolean;
  inlineRendering?: 'single-line' | 'multiline' | 'automatic';
  markdown?: any;
  postSubmissionActions?: Array<{ actionId: string; enabled?: string; config?: Record<string, any> }>;
  formOptions?: {
    usePreviousValueDisabled: boolean;
  };
  version?: string;
  translations?: Record<string, string>;
  meta?: {
    programs?: {
      hasProgramFields?: boolean;
      [anythingElse: string]: any;
    };
  };
}

export interface FormPage {
  label: string;
  isHidden?: boolean;
  hide?: HideProps;
  sections: Array<FormSection>;
  isSubform?: boolean;
  inlineRendering?: 'single-line' | 'multiline' | 'automatic';
  readonly?: string | boolean;
  subform?: {
    name?: string;
    package?: string;
    behaviours?: Array<any>;
    form: Omit<FormSchema, 'postSubmissionActions'>;
  };
  id?: string;
}

export interface FormSection {
  hide?: HideProps;
  label: string;
  isExpanded: string;
  isHidden?: boolean;
  isParentHidden?: boolean;
  questions: Array<FormField>;
  inlineRendering?: 'single-line' | 'multiline' | 'automatic';
  readonly?: string | boolean;
  reference?: FormReference;
}

export interface FormField {
  label?: string;
  type: string;
  questionOptions: FormQuestionOptions;
  datePickerFormat?: 'both' | 'calendar' | 'timer';
  id: string;
  questions?: Array<FormField>;
  value?: any;
  hide?: HideProps;
  isHidden?: boolean;
  isParentHidden?: boolean;
  fieldDependents?: Set<string>;
  pageDependents?: Set<string>;
  sectionDependents?: Set<string>;
  isRequired?: boolean;
  required?: string | boolean | RequiredFieldProps;
  unspecified?: boolean;
  isDisabled?: boolean;
  disabled?: boolean | Omit<DisableProps, 'isDisabled'>;
  readonly?: string | boolean;
  isReadonly?: boolean;
  inlineRendering?: 'single-line' | 'multiline' | 'automatic';
  validators?: Array<Record<string, any>>;
  behaviours?: Array<Record<string, any>>;
  questionInfo?: string;
  historicalExpression?: string;
  constrainMaxWidth?: boolean;
  hideSteppers?: boolean;
  /** @deprecated */
  inlineMultiCheckbox?: boolean;
  meta?: QuestionMetaProps;
}

export interface HideProps {
  hideWhenExpression: string;
}

export interface DisableProps {
  disableWhenExpression?: string;
  isDisabled?: boolean;
}

export interface RequiredFieldProps {
  type: string;
  message?: string;
  referenceQuestionId: string;
  referenceQuestionAnswers: Array<string>;
}

export interface RepeatOptions {
  addText?: string;
  limit?: string;
  limitExpression?: string;
}

export interface QuestionMetaProps {
  concept?: OpenmrsResource;
  initialValue?: {
    omrsObject: OpenmrsResource | Array<OpenmrsResource>;
    refinedValue?: string | number | Date | Array<string | number>;
  };
  submission?: {
    voidedValue?: any;
    newValue?: any;
    unspecified?: boolean;
    errors?: any[];
    warnings?: any[];
  };
  repeat?: {
    isClone?: boolean;
    wasDeleted?: boolean;
  };
  groupId?: string;
  pageId?: string;
  [anythingElse: string]: any;
}

export interface FormQuestionOptions {
  extensionId?: string;
  extensionSlotName?: string;
  rendering: RenderType;
  concept?: string;
  /**
   * max and min are used to validate number field values
   */
  max?: string;
  min?: string;
  /**
   * specifies the increment or decrement step for number field values
   */
  step?: number;
  /**
   * @description
   * Indicates whether the field is transient.
   * - Transient fields are ignored on form submission.
   * - If set to __true__, the field is omitted from the O3 Form in `embedded-view` mode.
   * @default false
   */
  isTransient?: boolean;
  /**
   * maxLength and maxLength are used to validate text field length
   */
  maxLength?: string;
  minLength?: string;
  showDate?: string;
  shownDateOptions?: { validators?: Array<Record<string, any>>; hide?: { hideWhenExpression: string } };
  answers?: Array<QuestionAnswerOption>;
  weeksList?: string;
  locationTag?: string;
  disallowDecimals?: boolean;
  rows?: number;
  toggleOptions?: { labelTrue: string; labelFalse: string };
  repeatOptions?: RepeatOptions;
  defaultValue?: any;
  calculate?: {
    calculateExpression: string;
  };
  isDateTime?: { labelTrue: boolean; labelFalse: boolean };
  enablePreviousValue?: boolean;
  allowedFileTypes?: Array<string>;
  allowMultiple?: boolean;
  datasource?: { name: string; config?: Record<string, any> };
  /**
   * Determines if the ui-select-extended rendering is searchable
   */
  isSearchable?: boolean;
  /**
   * Determines if the checkbox rendering is searchable
   */
  isCheckboxSearchable?: boolean;
  workspaceName?: string;
  workspaceProps?: Record<string, any>;
  buttonLabel?: string;
  identifierType?: string;
  attributeType?: string;
  orderSettingUuid?: string;
  orderType?: string;
  selectableOrders?: Array<Record<any, any>>;
  programUuid?: string;
  workflowUuid?: string;
  showComment?: boolean;
  comment?: string;
  orientation?: 'vertical' | 'horizontal';
  shownCommentOptions?: { validators?: Array<Record<string, any>>; hide?: { hideWhenExpression: string } };
  diagnosis?: {
    rank?: number;
    isConfirmed?: boolean;
    conceptClasses?: Array<string>;
    conceptSet?: string;
  };
}

export interface QuestionAnswerOption {
  hide?: HideProps;
  disable?: DisableProps;
  label?: string;
  concept?: string;
  [key: string]: any;
}

export type RenderType =
  | 'checkbox'
  | 'bed-select'
  | 'checkbox-searchable'
  | 'content-switcher'
  | 'date'
  | 'datetime'
  | 'drug'
  | 'encounter-location'
  | 'encounter-provider'
  | 'multi-provider-select'
  | 'encounter-role'
  | 'fixed-value'
  | 'file'
  | 'group'
  | 'number'
  | 'problem'
  | 'radio'
  | 'repeating'
  | 'select'
  | 'text'
  | 'textarea'
  | 'toggle'
  | 'ui-select-extended'
  | 'workspace-launcher'
  | 'markdown'
  | 'extension-widget'
  | 'select-concept-answers'
  /**
   * Renders a datetime picker (date + time) with the time defaulting to the
   * current time. Signals that submitting this form should also create (or
   * update) an OpenMRS appointment.
   * Pair with the `AppointmentSubmissionAction` post-submission action.
   */
  | 'appointment';

/**
 * Represents an OpenMRS appointment service as returned by
 * `GET /ws/rest/v1/appointmentService/all/default`.
 */
export interface AppointmentService {
  uuid: string;
  name: string;
  description?: string;
  speciality?: {
    name: string;
    uuid: string;
  };
  startTime?: string;
  endTime?: string;
  maxAppointmentsLimit?: number | null;
  durationMins?: number | null;
  location?: {
    uuid?: string;
    display?: string;
  };
  color?: string;
  initialAppointmentStatus?: string;
}

export interface FormReference {
  form: string;
  page: string;
  section: string;
  excludeQuestions?: Array<string>;
}

export interface ReferencedForm {
  formName: string;
  alias: string;
}

export type FormExpanded = boolean | undefined;
